gcc lab_linear.c -lm -o out_linear
