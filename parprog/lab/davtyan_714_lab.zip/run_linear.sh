./out_linear 3 4 800 10000
