mpirun -np 2 out 3 4 800 10000
