mpicc lab.c -lm -o out
